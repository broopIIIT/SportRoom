from django.contrib import admin
from sportsEquipment.models import Equipments
from login.models import UserProfileInfo
# admin.site.register(UserProfileInfo)
admin.site.register(Equipments)



