from django.apps import AppConfig


class SportsequipmentConfig(AppConfig):
    name = 'sportsEquipment'
